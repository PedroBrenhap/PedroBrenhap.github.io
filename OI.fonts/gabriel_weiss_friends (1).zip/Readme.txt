Gabriel Weiss' Friends Font


GWFF is the result of a personal project in 2003.


This font is free for personal use.
For commercial use, please contact me with some information about the project at gabrielweiss@gmx.ch

If you enjoy using the font, please consider donating at https://www.paypal.me/gweiss82


Enjoy.
G.

2018